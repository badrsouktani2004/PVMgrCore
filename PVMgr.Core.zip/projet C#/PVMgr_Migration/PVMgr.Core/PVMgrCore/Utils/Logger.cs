﻿using System;
using System.IO;

namespace PVMgr.Core.Utils
{
    public static class Logger
    {

        private static readonly string LogFilePath = @"C:\Temp\TestStand_PVMgr_Log.txt";

        /// <summary>
        /// Écrit un message d'erreur formaté dans un fichier texte.
        /// 
        /// <param name="module">Le nom du sous-VI ou du service (ex: "MAIN", "PARAM GET")</param>
        /// 
        /// <param name="message">Le message descriptif du problème</param>
        /// 
        /// <param name="ex">L'exception C# capturée (optionnel)</param>
        /// </summary>

        public static void WriteError(string module, string message, Exception ex = null)
        {
            try
            {
                string directory = Path.GetDirectoryName(LogFilePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                string timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                string logLine = $"[{timeStamp}] [{module}] {message}";

                if (ex != null)
                {
                    logLine += $" | Détails techniques : {ex.Message}";
                }

                File.AppendAllText(LogFilePath, logLine + Environment.NewLine);
            }
            catch
            {
                // Bloc de sécurité absolu : si l'écriture du fichier échoue (ex: disque plein),
                // on capture l'erreur ici en silence pour ne JAMAIS faire crasher TestStand.
            }
        }
    }
}