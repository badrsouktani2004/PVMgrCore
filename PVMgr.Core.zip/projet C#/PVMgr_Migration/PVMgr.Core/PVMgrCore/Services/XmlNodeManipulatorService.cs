﻿using System;
using System.Xml;
using System.Collections;
using System.Runtime.InteropServices;
using PVMgr.Core.Utils;

namespace PVMgr.Core.Services
{
    public class XmlNodeManipulatorService
    {
        /// <summary>
        /// Équivalent du Sous-VI AddDataToXML + SES 4 Sous-Vi :
        ///  "AddNode" / "AddStringValue" / "ReplaceNode" / "ReplaceStringValue"
        /// </summary>
        public Exception ManipulateXmlNode(XmlDocument docRef, XmlNode parentNode, dynamic reportContent, string ifExist, string dataName, Exception errorIn)
        {
            if (errorIn != null) return errorIn;

            XmlNode childNode = null;
            try
            {
                childNode = parentNode.SelectSingleNode(dataName);
            }
            catch (Exception ex)
            {
                Logger.WriteError("TS-XML", $"Erreur de syntaxe XPath sur le nœud '{dataName}'", ex);
                return ex;
            }

            bool isNodeMissing = (childNode == null);
            string actualCommand = isNodeMissing ? "add" : ifExist;

            try
            {
                switch (actualCommand)
                {
                    case "cancel":
                        if (childNode != null) childNode = null;
                        break;

                    case "add":
                        if (childNode != null) childNode = null;

                        int valueTypeAdd = -1;
                        dynamic typeObjAdd = null; 

                        try
                        {
                            if (reportContent != null)
                            {
                                typeObjAdd = reportContent.Type;
                                if (typeObjAdd != null)
                                {
                                    valueTypeAdd = (int)typeObjAdd.ValueType;
                                }
                            }
                        }
                        finally
                        {
                            if (typeObjAdd != null && Marshal.IsComObject(typeObjAdd))
                            {
                                Marshal.ReleaseComObject(typeObjAdd);
                                typeObjAdd = null;
                            }
                        }

                        switch (valueTypeAdd)
                        {
                            case 0: 
                                XmlElement newContainerAdd = docRef.CreateElement(dataName);
                                parentNode.AppendChild(newContainerAdd);

                                dynamic subPropsAdd = null;
                                try
                                {
                                    subPropsAdd = reportContent.GetSubProperties("", 0);
                                    if (subPropsAdd != null)
                                    {
                                        foreach (dynamic subProperty in (IEnumerable)subPropsAdd)
                                        {
                                            try
                                            {
                                                if (subProperty != null)
                                                {
                                                    errorIn = ManipulateXmlNode(docRef, newContainerAdd, subProperty, "add", subProperty.Name, errorIn);
                                                }
                                            }
                                            finally
                                            {
                                                if (subProperty != null && Marshal.IsComObject(subProperty))
                                                {
                                                    Marshal.ReleaseComObject(subProperty);
                                                }
                                            }
                                        }
                                    }
                                }
                                finally
                                {
                                    if (subPropsAdd != null && Marshal.IsComObject(subPropsAdd))
                                    {
                                        Marshal.ReleaseComObject(subPropsAdd);
                                        subPropsAdd = null;
                                    }
                                }
                                break;

                            case 1:
                            case 2:
                            case 3:
                            case 7: 
                                int optionsAdd = 0;
                                switch (valueTypeAdd)
                                {
                                    case 1: optionsAdd = 0x00; break;
                                    case 2: optionsAdd = 0x20; break;
                                    case 3: optionsAdd = 0x08; break;
                                    case 7: optionsAdd = 0xC0; break;
                                }

                                string tagValueAdd = reportContent.GetValString("", optionsAdd);
                                XmlElement newElementAdd = docRef.CreateElement(dataName);
                                XmlText textNodeAdd = docRef.CreateTextNode(tagValueAdd);
                                newElementAdd.AppendChild(textNodeAdd);
                                parentNode.AppendChild(newElementAdd);
                                break;

                            case 5: 
                                dynamic referencedObjectAdd = null;
                                try
                                {
                                    referencedObjectAdd = reportContent.GetValInterface("", 0);
                                    if (referencedObjectAdd != null)
                                    {
                                        errorIn = ManipulateXmlNode(docRef, parentNode, referencedObjectAdd, "add", dataName, errorIn);
                                    }
                                }
                                finally
                                {
                                    if (referencedObjectAdd != null && Marshal.IsComObject(referencedObjectAdd))
                                    {
                                        Marshal.ReleaseComObject(referencedObjectAdd);
                                        referencedObjectAdd = null;
                                    }
                                }
                                break;

                            case 6: 
                                int numElements = reportContent.GetNumElements();
                                for (int i = 0; i < numElements; i++)
                                {
                                    dynamic arrayElement = null;
                                    try
                                    {
                                        arrayElement = reportContent.GetPropertyObjectByOffset(i, 0);
                                        if (arrayElement != null)
                                        {
                                            errorIn = ManipulateXmlNode(docRef, parentNode, arrayElement, "add", dataName, errorIn);
                                        }
                                    }
                                    finally
                                    {
                                        if (arrayElement != null && Marshal.IsComObject(arrayElement))
                                        {
                                            Marshal.ReleaseComObject(arrayElement);
                                            arrayElement = null;
                                        }
                                    }
                                }
                                break;

                            case 4:
                            default:
                                Exception typeError = new Exception($"PropertyObject type invalid : {dataName}");
                                typeError.Data["Code"] = -1;
                                throw typeError;
                        }
                        break;

                    case "replace":
                        int valueTypeReplace = -1;
                        dynamic typeObjReplace = null;

                        try
                        {
                            if (reportContent != null)
                            {
                                typeObjReplace = reportContent.Type;
                                if (typeObjReplace != null)
                                {
                                    valueTypeReplace = (int)typeObjReplace.ValueType;
                                }
                            }
                        }
                        finally
                        {
                            if (typeObjReplace != null && Marshal.IsComObject(typeObjReplace))
                            {
                                Marshal.ReleaseComObject(typeObjReplace);
                                typeObjReplace = null;
                            }
                        }

                        switch (valueTypeReplace)
                        {
                            case 0: 
                                XmlElement newContainerReplace = docRef.CreateElement(dataName);
                                parentNode.ReplaceChild(newContainerReplace, childNode);

                                dynamic subPropsReplace = null;
                                try
                                {
                                    subPropsReplace = reportContent.GetSubProperties("", 0);
                                    if (subPropsReplace != null)
                                    {
                                        foreach (dynamic subProperty in (IEnumerable)subPropsReplace)
                                        {
                                            try
                                            {
                                                if (subProperty != null)
                                                {
                                                    errorIn = ManipulateXmlNode(docRef, newContainerReplace, subProperty, "add", subProperty.Name, errorIn);
                                                }
                                            }
                                            finally
                                            {
                                                if (subProperty != null && Marshal.IsComObject(subProperty))
                                                {
                                                    Marshal.ReleaseComObject(subProperty);
                                                }
                                            }
                                        }
                                    }
                                }
                                finally
                                {
                                    if (subPropsReplace != null && Marshal.IsComObject(subPropsReplace))
                                    {
                                        Marshal.ReleaseComObject(subPropsReplace);
                                        subPropsReplace = null;
                                    }
                                }
                                break;

                            case 1:
                            case 2:
                            case 3:
                            case 7:
                                int optionsReplace = 0;
                                switch (valueTypeReplace)
                                {
                                    case 1: optionsReplace = 0x00; break;
                                    case 2: optionsReplace = 0x20; break;
                                    case 3: optionsReplace = 0x08; break;
                                    case 7: optionsReplace = 0xC0; break;
                                }

                                string tagValueReplace = reportContent.GetValString("", optionsReplace);
                                XmlElement newElementReplace = docRef.CreateElement(dataName);
                                XmlText textNodeReplace = docRef.CreateTextNode(tagValueReplace);
                                newElementReplace.AppendChild(textNodeReplace);
                                parentNode.ReplaceChild(newElementReplace, childNode);
                                break;

                            case 5: 
                                dynamic referencedObjectReplace = null;
                                try
                                {
                                    referencedObjectReplace = reportContent.GetValInterface("", 0);
                                    if (referencedObjectReplace != null)
                                    {
                                        errorIn = ManipulateXmlNode(docRef, parentNode, referencedObjectReplace, "replace", dataName, errorIn);
                                    }
                                }
                                finally
                                {
                                    if (referencedObjectReplace != null && Marshal.IsComObject(referencedObjectReplace))
                                    {
                                        Marshal.ReleaseComObject(referencedObjectReplace);
                                        referencedObjectReplace = null;
                                    }
                                }
                                break;

                            case 6:
                                Exception arrayError = new Exception("You can't replace an array");
                                arrayError.Data["Code"] = -1;
                                throw arrayError;

                            case 4:
                            default:
                                Exception typeError = new Exception($"PropertyObject type invalid : {dataName}");
                                typeError.Data["Code"] = -1;
                                throw typeError;
                        }
                        childNode = null;
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteError("TS-XML Manipulator", $"Plantage sur le nœud '{dataName}'", ex);
                errorIn = ex;
            }
            finally
            {
                
                if (reportContent != null && Marshal.IsComObject(reportContent))
                {
                    Marshal.ReleaseComObject(reportContent);
                }
            }

            return errorIn;
        }
    }
}