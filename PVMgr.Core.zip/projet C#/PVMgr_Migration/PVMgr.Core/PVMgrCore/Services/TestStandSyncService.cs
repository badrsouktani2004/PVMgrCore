﻿using PVMgr.Core.Models;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using PVMgr.Core.Utils;

namespace PVMgr.Core.Services
{
    public class TestStandSyncService
    {
        /// <summary>
        /// Équivalent du Sous-VI "SetReportsInfo". 
        /// Pont de synchronisation et nettoyage des rapports dans TestStand.
        /// </summary>
        public Exception ParamSet_SyncWithTestStand(
            List<ReportInfo> reportsIn,
            dynamic sequenceContextIn,
            string lookupString,
            Exception errorIn)
        {

            if (errorIn != null)
            {
                return errorIn;
            }

            dynamic propertyObject = null;
            dynamic finalParentContainer = null;

            try
            {
                propertyObject = sequenceContextIn.AsPropertyObject();
                List<int> validIndices = new List<int>();

                foreach (var report in reportsIn)
                {
                    
                    dynamic targetElement = null;
                    dynamic parentContainer = null;

                    try
                    {
                        string fullLookupPath = $"{lookupString}[\"{report.ReportName}\"]";
                        bool elementExists = propertyObject.Exists(fullLookupPath, 0);

                        if (!elementExists)
                        {
                            parentContainer = propertyObject.GetPropertyObject(lookupString, 0);
                            int currentCount = parentContainer.GetNumElements();

                            parentContainer.InsertElements(currentCount, 1, 0);
                            targetElement = parentContainer.GetPropertyObjectByOffset(currentCount, 0);

                            targetElement.Name = report.ReportName;
                        }
                        else
                        {
                            targetElement = propertyObject.GetPropertyObject(fullLookupPath, 0);
                        }

                        targetElement.SetValString("ReportName", 1, report.ReportName);
                        targetElement.SetValString("Path", 1, report.Path);
                        targetElement.SetValNumber("FileSize", 1, report.FileSize);
                        targetElement.SetValNumber("LastUseTime", 1, report.LastUseTime.ToOADate());
                        targetElement.SetValNumber("OpenTime", 1, report.OpenTime.ToOADate());

                        int arrayIndex = propertyObject.GetArrayOffset(lookupString, 0, $"[\"{report.ReportName}\"]");
                        validIndices.Add(arrayIndex);
                    }
                    finally
                    {
                        
                        if (parentContainer != null && Marshal.IsComObject(parentContainer))
                        {
                            Marshal.ReleaseComObject(parentContainer);
                            parentContainer = null;
                        }
                        if (targetElement != null && Marshal.IsComObject(targetElement))
                        {
                            Marshal.ReleaseComObject(targetElement);
                            targetElement = null;
                        }
                    }
                }

                finalParentContainer = propertyObject.GetPropertyObject(lookupString, 0);
                int totalElementsInTestStand = finalParentContainer.GetNumElements();

                for (int i = totalElementsInTestStand - 1; i >= 0; i--)
                {
                    if (!validIndices.Contains(i))
                    {
                        finalParentContainer.DeleteElements(i, 1, 0);
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Logger.WriteError("PARAM SET", "Échec de la synchronisation avec TestStand", ex);
                return ex;
            }
            finally
            {
                
                if (finalParentContainer != null && Marshal.IsComObject(finalParentContainer))
                {
                    Marshal.ReleaseComObject(finalParentContainer);
                    finalParentContainer = null;
                }

                if (propertyObject != null && Marshal.IsComObject(propertyObject))
                {
                    Marshal.ReleaseComObject(propertyObject);
                    propertyObject = null;
                }
            }
        }
    }
}