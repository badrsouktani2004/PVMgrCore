﻿using PVMgr.Core.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using PVMgr.Core.Utils;

namespace PVMgr.Core.Services
{
    public class ReportManagerService
    {
        /// <summary>
        /// Équivalent du Sous-VI : "PeriodicSave"
        /// </summary>
        public (List<ReportInfo> ReportsOut, Exception ErrorOut) ManageReportTimeouts(List<ReportInfo> reportsIn, double useTimeOut, double openTimeOut, Exception errorIn)
        {
            Exception loopError = errorIn;

            try
            {
                foreach (var report in reportsIn)
                {
                    if (report.DocRef == null)
                    {
                        continue;
                    }

                    double inactiveTime = (DateTime.Now - report.LastUseTime).TotalSeconds;
                    double openDuration = (DateTime.Now - report.OpenTime).TotalSeconds;

                    if (inactiveTime > useTimeOut || openDuration > openTimeOut)
                    {
                        Exception saveError = SaveAndCloseDocument(report.DocRef, report.Path);

                        if (saveError != null && loopError == null)
                        {
                            loopError = saveError;
                        }

                        try
                        {
                            if (File.Exists(report.Path))
                            {
                                FileInfo fileInfo = new FileInfo(report.Path);
                                report.FileSize = fileInfo.Length;
                            }
                        }
                        catch (Exception fileEx)
                        {
                            Logger.WriteError("MAIN (Timeouts)", $"Impossible de lire la taille du fichier : {report.Path}", fileEx);
                            if (loopError == null) loopError = fileEx;
                        }

                        report.DocRef = null;
                        report.OpenTime = DateTime.MinValue;
                        report.LastUseTime = DateTime.MinValue;

                        break;
                    }
                }

                return (reportsIn, loopError);
            }
            catch (Exception ex)
            {
                Logger.WriteError("MAIN (Timeouts)", "Plantage inattendu lors de la gestion des timeouts.", ex);
                return (reportsIn, loopError ?? ex);
            }
        }

        /// <summary>
        /// Équivalent du Sous-VI "SaveCloseDocument"
        /// </summary>
        private Exception SaveAndCloseDocument(object docRef, string filePath)
        {
            try
            {
                if (docRef is XmlDocument xmlDoc)
                {
                    xmlDoc.Save(filePath);

                    //GC.Collect();
                    //GC.WaitForPendingFinalizers();

                    return null;
                }
                else
                {
                    Exception typeError = new InvalidCastException($"L'objet fourni n'est pas un XmlDocument valide.");
                    Logger.WriteError("XML Save", $"Fichier cible : {filePath}", typeError);
                    return typeError;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteError("XML Save", $"Impossible de sauvegarder le fichier {filePath}", ex);
                return ex;
            }
        }
        /// <summary>
        /// Équivalent du Sous-VI "SelectReport" 
        /// Cherche un rapport par son nom dans la liste globale
        /// </summary>
        public ReportLookupResult LookupReport(List<ReportInfo> reportsIn, string reportName, Exception errorIn)
        {

            if (reportsIn == null)
            {
                
                throw new ArgumentNullException(nameof(reportsIn), "Attention: la liste de rapports 'null'");
            }

            if (errorIn != null)
            {
                return new ReportLookupResult
                {
                    ReportsOut = reportsIn,
                    Report = new ReportInfo(), 
                    ReportIndex = 0,           
                    ErrorOut = errorIn
                };
            }

            try
            {
                
                int foundIndex = reportsIn.FindIndex(r => r.ReportName == reportName);

                if (foundIndex != -1)
                {
                    return new ReportLookupResult
                    {
                        ReportsOut = reportsIn,
                        Report = reportsIn[foundIndex],
                        ReportIndex = foundIndex,
                        ErrorOut = null
                    };
                }

                
                string errorMessage = $"the report name does not exist : {reportName}";
                Exception customError = new Exception(errorMessage);
                customError.Data["Code"] = 0; 

                return new ReportLookupResult
                {
                    ReportsOut = reportsIn,
                    Report = new ReportInfo(), 
                    ReportIndex = 0,          
                    ErrorOut = customError
                };
            }
            catch (Exception ex)
            {

                string errorMessage = $"ERREUR INATTENDUE CAPTURÉE ! Recherche du rapport : {reportName}";

                Logger.WriteError("LookupReport", errorMessage, ex);


                return new ReportLookupResult
                {
                    ReportsOut = reportsIn,
                    Report = new ReportInfo(),
                    ReportIndex = 0,
                    ErrorOut = ex
                };
            }
        }
        /// <summary>
        /// Équivalent du Sous-VI : "CheckAndOpen" + son sous-Vi "OpenDocument"
        /// Vérifie si le fichier est ouvert. Si non, l'ouvre et met à jour le cluster.
        /// </summary>
        public ReportOpenResult OpenReportDocument(ReportInfo reportIn, Exception errorIn)
        {
            
            if (errorIn != null)
            {
                return new ReportOpenResult
                {
                    ReportOut = reportIn,
                    ErrorOut = errorIn
                };
            }

            try
            {
                
                if (reportIn.DocRef == null)
                {
                    
                    XmlDocument xmlDoc = new XmlDocument();

                    xmlDoc.Load(reportIn.Path);

                    reportIn.DocRef = xmlDoc;
                    reportIn.OpenTime = DateTime.Now; 
                }
               
                return new ReportOpenResult
                {
                    ReportOut = reportIn,
                    ErrorOut = null
                };
            }
            catch (Exception ex)
            {
                string errorMessage = $"ERREUR D'OUVERTURE XML ! Chemin du fichier : {reportIn.Path}";
                Logger.WriteError("OpenReportDocument", errorMessage, ex);

                return new ReportOpenResult
                {

                    ReportOut = reportIn,
                    ErrorOut = ex
                };
            }
        }

    }



}
