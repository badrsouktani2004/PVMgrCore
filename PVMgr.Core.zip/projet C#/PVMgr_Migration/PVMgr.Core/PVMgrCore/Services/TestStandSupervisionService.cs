﻿using PVMgr.Core.Models;
using System;
using System.Runtime.InteropServices;
using NationalInstruments.TestStand.Interop.API;
using PVMgr.Core.Utils;

namespace PVMgr.Core.Services
{
    public class TestStandSupervisionService
    {
        /// <summary>
        /// Équivalent du Sous-VI "Supervision d'arrêt de séquence".
        /// Gardien de l'arrêt du banc de test.
        /// </summary>
        public (StatusMonitor MonitorOut, bool TerminatingOrAborting, Exception ErrorOut)
            CheckTerminationStatus(StatusMonitor monitorIn, Exception errorIn)
        {

            if (errorIn != null)
            {
                return (monitorIn, false, errorIn);
            }

            try
            {

                var execution = monitorIn.Execution;
                var terminationMonitorData = monitorIn.TerminationMonitor;
                var sequenceContextParam = monitorIn.Context;


                bool isStopping = ((dynamic)execution).GetTerminationMonitorStatus(
                    terminationMonitorData,
                    sequenceContextParam
                );


                return (monitorIn, isStopping, null);
            }
            catch (Exception ex)
            {
                Logger.WriteError("Supervision TS", "Échec de l'interrogation d'arrêt TestStand", ex);

                return (monitorIn, false, ex);
            }
        }

        /// <summary>
        /// Équivalent du Sous-VI "Fermeture Moniteur d'arret de sequence".
        /// </summary>
        public Exception CloseTerminationMonitor(StatusMonitor monitorIn, Exception errorIn)
        {
            Exception currentError = errorIn;

            if (monitorIn == null) return currentError;

            try
            {
                
                if (monitorIn.TerminationMonitor != null && Marshal.IsComObject(monitorIn.TerminationMonitor))
                {
                    Marshal.ReleaseComObject(monitorIn.TerminationMonitor);
                    monitorIn.TerminationMonitor = null;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteError("CloseMonitor", "Échec de la libération mémoire du TerminationMonitor", ex);
                Exception closeError = new Exception($"Échec de la fermeture du TerminationMonitor : {ex.Message}", ex);
                currentError = currentError ?? closeError;
            }
            finally
            {
                
                try
                {
                    if (monitorIn.Execution != null && Marshal.IsComObject(monitorIn.Execution))
                    {
                        Marshal.ReleaseComObject(monitorIn.Execution);
                        monitorIn.Execution = null;
                    }
                }
                catch (Exception ex)
                {
                    Logger.WriteError("CloseMonitor", "Échec de la libération mémoire de Execution", ex);
                    Exception closeError = new Exception($"Échec de la fermeture de Execution : {ex.Message}", ex);
                    currentError = currentError ?? closeError;
                }
            }

            return currentError;
        }
    }
}