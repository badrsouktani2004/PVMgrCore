﻿using NationalInstruments.TestStand.Interop.API;
using PVMgr.Core.Models;
using PVMgr.Core.Utils;
using System;
using System.Runtime.InteropServices;
using TSSyncLib;

namespace PVMgr.Core.Services
{
    public class TestStandService
    {
        public TestStandService() { }

        /// <summary>
        /// Équivalent du Sous-VI : "Initialisation Moniteur d'arrêt de séquence"
        /// </summary>
        public (StatusMonitor MonitorOut, Exception ErrorOut) InitializeTerminationMonitor(SequenceContext sequenceContextIn, Exception errorIn)
        {
            if (errorIn != null)
            {
                return (new StatusMonitor(), errorIn);
            }

            if (sequenceContextIn == null)
            {
                Exception argError = new ArgumentNullException(nameof(sequenceContextIn), "Le contexte de séquence fourni est nul.");
                return (new StatusMonitor(), argError);
            }

            try
            {
                var statusMonitorOut = new StatusMonitor();
                statusMonitorOut.Context = sequenceContextIn;
                statusMonitorOut.Execution = sequenceContextIn.Execution;
                statusMonitorOut.TerminationMonitor = statusMonitorOut.Execution.InitTerminationMonitor();
                return (statusMonitorOut, null);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Erreur TestStand] Échec de l'initialisation du moniteur : {ex.Message}");
                return (new StatusMonitor(), ex);
            }
        }

        /// <summary>
        /// Équivalent du Sous-VI : "GetParameters" 
        /// </summary>
        public (Parameter ParamOut, Exception ErrorOut) ReadParametersFromSequence(SequenceContext context, string lookupString, Exception errorIn)
        {
            if (errorIn != null)
            {
                return (new Parameter(), errorIn);
            }

            if (context == null)
            {
                Exception argErr = new ArgumentNullException(nameof(context), "Le contexte de séquence est nul.");
                return (new Parameter(), argErr);
            }
            if (string.IsNullOrEmpty(lookupString))
            {
                Exception argErr = new ArgumentNullException(nameof(lookupString), "La chaîne lookup est vide.");
                return (new Parameter(), argErr);
            }

            var parameters = new Parameter();
            PropertyObject propObj = null; // 1. On prépare la référence COM en haut

            try
            {
                propObj = context.AsPropertyObject(); // 2. On récupère l'objet

                parameters.Stop = propObj.GetValBoolean(lookupString + ".Stop", 0);
                parameters.Abort = propObj.GetValBoolean(lookupString + ".Abort", 0);

                parameters.OpenTimeOut = (double)propObj.GetValNumber(lookupString + ".OpenTimeOut", 0);
                parameters.UseTimeOut = (double)propObj.GetValNumber(lookupString + ".UseTimeOut", 0);

                return (parameters, null);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Erreur PARAM GET] Impossible de lire les paramètres : {ex.Message}");
                return (new Parameter(), ex);
            }
            finally
            {
                
                if (propObj != null && Marshal.IsComObject(propObj))
                {
                    Marshal.ReleaseComObject(propObj);
                    propObj = null;
                }
            }
        }

        /// <summary>
        /// Équivalent du Sous-VI : "TSDequeue" (Timed Structure Queue Reader)
        /// Lit la file d'attente TestStand de manière asynchrone avec Timeout.
        /// </summary>
        public QueueMessageResult ReadCommandFromQueue(SequenceContext contextIn, string queueName, Exception errorIn)
        {
            if (errorIn != null)
            {
                return new QueueMessageResult { Command = "", CmdContent = null, IsEmpty = true, Error = errorIn };
            }

            IEngine engine = null;
            ISyncManager syncManager = null;
            IQueue queue = null;
            PropertyObject destObj = null;

            try
            {
                engine = contextIn.Engine;
                syncManager = (ISyncManager)engine.GetSyncManager(queueName);
                queue = (IQueue)syncManager.GetQueue(queueName);

                int enqueueWait, dequeueWait, sizeLimit, numElements;
                queue.GetInfo(null, null, out enqueueWait, out dequeueWait, out sizeLimit, out numElements);

                if (numElements == 0)
                {
                    return new QueueMessageResult { Command = "NA", CmdContent = null, IsEmpty = true, Error = null };
                }
                else
                {
                    destObj = engine.NewPropertyObject(PropertyValueTypes.PropValType_Reference, false, "", 0);

                    bool processMsgs = (contextIn != null);

                    queue.Dequeue(true, true, destObj, 0.01, contextIn, processMsgs, out WaitResult _);

                    string command = "NA";
                    PropertyObject content = null;

                    if (destObj != null && destObj.Exists("Command", 0))
                    {
                        command = destObj.GetValString("Command", 0);

                        if (destObj.Exists("Content", 0))
                        {
                            content = destObj.GetPropertyObject("Content", 0);
                        }
                        else
                        {
                            Exception formatEx = new Exception($"Message malformé reçu depuis la file '{queueName}'. La propriété 'Command' est introuvable.");
                            formatEx.Data["Code"] = -1;
                            throw formatEx;
                        }
                    }
                    else
                    {
                        throw new Exception($"L'objet extrait de la file '{queueName}' est nul (Null Reference).");
                    }

                    bool isEmpty = (command == "NA");

                    return new QueueMessageResult { Command = command, CmdContent = content, IsEmpty = isEmpty, Error = null };
                }
            }
            catch (Exception ex)
            {
                Logger.WriteError("Lecture Queue", $"Plantage lors de la lecture de la file {queueName}", ex);
                return new QueueMessageResult { Command = "", CmdContent = null, IsEmpty = true, Error = ex };
            }
            finally
            {
                
                if (destObj != null && Marshal.IsComObject(destObj))
                {
                    Marshal.ReleaseComObject(destObj);
                }
                if (queue != null && Marshal.IsComObject(queue))
                {
                    Marshal.ReleaseComObject(queue);
                }
                if (syncManager != null && Marshal.IsComObject(syncManager))
                {
                    Marshal.ReleaseComObject(syncManager);
                }
                if (engine != null && Marshal.IsComObject(engine))
                {
                    Marshal.ReleaseComObject(engine);
                }
            }
        }

        /// <summary>
        /// Équivalent du Sous-VI : "TSGetReportData"
        /// Extrait les paramètres vitaux de la commande "post" .
        /// </summary>
        public (PostCommandData DataOut, Exception ErrorOut) ParsePostContent(PropertyObject cmdContent, Exception errorIn)
        {
            if (errorIn != null)
            {
                return (new PostCommandData { ReportName = "", XPath = "", DataName = "", IfExist = "", ReportContent = null }, errorIn);
            }

            if (cmdContent == null)
            {
                Exception argErr = new ArgumentNullException(nameof(cmdContent), "Le contenu de la commande Post est nul.");
                Logger.WriteError("Parse Post", "Impossible de lire la commande", argErr);

                return (new PostCommandData { ReportName = "", XPath = "", DataName = "", IfExist = "", ReportContent = null }, argErr);
            }

            try
            {
                string reportName = cmdContent.GetValString("ReportName", 0);
                string xPath = cmdContent.GetValString("XPATH", 0);
                string dataName = cmdContent.GetValString("DataName", 0);
                string ifExist = cmdContent.GetValString("IfExist", 0);

                PropertyObject reportContent = cmdContent.GetPropertyObject("DataContent", 0);

                var parsedData = new PostCommandData
                {
                    ReportName = reportName,
                    XPath = xPath,
                    DataName = dataName,
                    IfExist = ifExist,
                    ReportContent = reportContent // Libéré plus tard dans le MainOrchestrator
                };

                return (parsedData, null);
            }
            catch (Exception ex)
            {
                Logger.WriteError("Parse Post", "Échec de l'extraction des données PostContent depuis TestStand.", ex);
                var emptyData = new PostCommandData { ReportName = "", XPath = "", DataName = "", IfExist = "", ReportContent = null };
                return (emptyData, ex);
            }
        }

        /// <summary>
        /// Équivalent du sous-VI "TSGetNewDocData".
        /// Extrait les paramètres de création de rapport depuis l'objet TestStand.
        /// </summary>
        public (NewCommandInfo DataOut, Exception ErrorOut) ParseNewCommandContent(PropertyObject cmdContent, Exception errorIn)
        {
            var commandInfo = new NewCommandInfo
            {
                ReportName = "",
                FilePath = "",
                StyleSheetPath = "",
                IfExist = "",
                MainTag = ""
            };

            if (errorIn != null)
            {
                return (commandInfo, errorIn);
            }

            if (cmdContent == null)
            {
                Exception argErr = new ArgumentNullException(nameof(cmdContent), "Le contenu de la commande New est nul.");
                Logger.WriteError("Parse New", "Impossible de lire la commande", argErr);
                return (commandInfo, argErr);
            }

            try
            {
                commandInfo.ReportName = cmdContent.GetValString("ReportName", 0);
                commandInfo.FilePath = cmdContent.GetValString("FilePath", 0);
                commandInfo.StyleSheetPath = cmdContent.GetValString("StyleSheetPath", 0);
                commandInfo.IfExist = cmdContent.GetValString("IfExist", 0);
                commandInfo.MainTag = cmdContent.GetValString("MainTag", 0);

                return (commandInfo, null);
            }
            catch (Exception ex)
            {
                Logger.WriteError("Parse New", "Échec de l'extraction des données NewCommandContent depuis TestStand.", ex);
                return (commandInfo, ex);
            }
        }
    }
}