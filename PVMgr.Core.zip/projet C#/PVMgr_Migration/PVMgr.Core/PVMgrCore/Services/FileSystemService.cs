﻿using PVMgr.Core.Utils;
using System;
using System.IO;

namespace PVMgr.Core.Services
{
    public class FileSystemService
    {
        /// <summary>
        /// Équivalent du sous-VI "Check if file or Folder exists".
        /// </summary>
        public (bool Exists, Exception ErrorOut) CheckIfFileExists(string path, Exception errorIn)
        {
            if (errorIn != null)
            {
                return (false, errorIn);
            }

            if (string.IsNullOrWhiteSpace(path))
            {
                return (false, null);
            }

            try
            {

                bool fileExists = File.Exists(path) || Directory.Exists(path);

                return (fileExists, null);
            }
            catch (Exception ex)
            {

                string errorMessage = $"ERREUR DE VÉRIFICATION DU FICHIER ! Chemin testé : {path}";

                Logger.WriteError("CheckIfFileExists", errorMessage, ex);

                return (false, ex);
            }
        }
        /// <summary>
        /// Équivalent du Sous-VI "RenameExisting" .
        /// Utilisé par le cas "rename" pour incrémenter le nom du fichier (_01, _02...) s'il existe déjà.
        /// </summary>
        public (string UniquePath, Exception ErrorOut) GenerateUniqueFilename(string originalPath, Exception errorIn)
        {
            if (errorIn != null)
            {
                return (originalPath, errorIn);
            }

            try
            {
                string directory = Path.GetDirectoryName(originalPath) ?? string.Empty;
                string fileName = Path.GetFileNameWithoutExtension(originalPath);
                string extension = Path.GetExtension(originalPath);

                int counter = 1;
                string newPath = originalPath;

                while (File.Exists(newPath))
                {
                    string newFileName = $"{fileName}_{counter:D2}{extension}";
                    newPath = Path.Combine(directory, newFileName);
                    counter++;
                }

                return (newPath, null);
            }
            catch (Exception ex)
            {
                Logger.WriteError("GenerateUniqueFilename", $"Plantage lors de la génération du nom pour : {originalPath}", ex);

                return (originalPath, ex);
            }
        }
    }


}
