﻿using System;
using System.IO;
using PVMgr.Core.Utils; 

namespace PVMgr.Core.Services
{
    public class XmlFileCreatorService
    {
        /// <summary>
        /// Équivalent du Sous-VI "NewDocument".
        /// Crée physiquement le fichier XML avec son en-tête et sa balise racine.
        /// </summary>
        public Exception CreateXmlFile(string path, string styleSheetPath, string mainTag, Exception errorIn)
        {

            if (errorIn != null)
            {
                return errorIn; 
            }

            try
            {
                string xmlContent =
                    $"<?xml version=\"1.0\"?>\n" +
                    $"<?xml-stylesheet type=\"text/xsl\" href=\"{styleSheetPath}\"?>\n" +
                    $"<{mainTag}/>";

                File.WriteAllText(path, xmlContent);

                return null;
            }
            catch (Exception ex)
            {
    
                string errorMessage = $"ERREUR DE CRÉATION XML ! Chemin cible : {path}";

                Logger.WriteError("CreateXmlFile", errorMessage, ex);

                return ex;
            }
        }
    }
}