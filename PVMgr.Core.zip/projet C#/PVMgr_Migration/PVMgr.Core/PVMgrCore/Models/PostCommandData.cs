﻿using NationalInstruments.TestStand.Interop.API; 

namespace PVMgr.Core.Models
{
    public class PostCommandData
    {
        public string ReportName { get; set; }
        public string XPath { get; set; }
        public string DataName { get; set; }
        public string IfExist { get; set; }

        public PropertyObject ReportContent { get; set; }
    }
}