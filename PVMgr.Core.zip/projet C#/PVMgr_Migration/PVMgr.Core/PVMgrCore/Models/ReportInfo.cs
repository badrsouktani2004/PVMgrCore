﻿using System;

namespace PVMgr.Core.Models
{
    public class ReportInfo
    {
        public string ReportName { get; set; }

        public string Path { get; set; }

        public dynamic DocRef { get; set; }

        public long FileSize { get; set; }

        public DateTime OpenTime { get; set; }

        public DateTime LastUseTime { get; set; }
    }
}