﻿using NationalInstruments.TestStand.Interop.API;
using System;
using System.CodeDom.Compiler;

namespace PVMgr.Core.Models
{
    public class StatusMonitor
    {
       
        public SequenceContext Context { get; set; }
        public Execution Execution { get; set; }
        public object TerminationMonitor { get; set; }
    }
}