﻿using System;

namespace PVMgr.Core.Models
{
    public class Parameter
    {
        public bool Stop { get; set; }
        public bool Abort { get; set; }
        public double OpenTimeOut { get; set; }
        public double UseTimeOut { get; set; }

        public Parameter()
        {
            Stop = false;
            Abort = false;
            OpenTimeOut = 0;
            UseTimeOut = 0;
        }
    }
}