﻿using System;
using NationalInstruments.TestStand.Interop.API;

namespace PVMgr.Core.Models
{
    public class QueueMessageResult
    {
        
        public string Command { get; set; }
        public PropertyObject CmdContent { get; set; }
        public bool IsEmpty { get; set; }
        public Exception Error { get; set; }
    }
}