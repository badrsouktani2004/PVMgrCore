﻿
using System;
using System.Collections.Generic;

namespace PVMgr.Core.Models
{
    public class ReportLookupResult
    {
        
        public List<ReportInfo> ReportsOut { get; set; }

        public ReportInfo Report { get; set; }

        public int ReportIndex { get; set; }

        public Exception ErrorOut { get; set; }
    }
}