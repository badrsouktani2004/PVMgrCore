﻿using System;

namespace PVMgr.Core.Models
{
    public class ReportOpenResult
    {
        public ReportInfo ReportOut { get; set; }
        public Exception ErrorOut { get; set; }
    }
}