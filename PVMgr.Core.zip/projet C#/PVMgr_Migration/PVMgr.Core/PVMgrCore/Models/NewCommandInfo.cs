﻿namespace PVMgr.Core.Models
{
   public class NewCommandInfo
    {
        public string ReportName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string StyleSheetPath { get; set; } = string.Empty;
        public string IfExist { get; set; } = string.Empty;
        public string MainTag { get; set; } = string.Empty;
    }
}