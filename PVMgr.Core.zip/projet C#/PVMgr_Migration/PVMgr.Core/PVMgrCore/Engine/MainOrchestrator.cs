﻿using NationalInstruments.TestStand.Interop.API;
using PVMgr.Core.Models;
using PVMgr.Core.Services;
using PVMgr.Core.Utils;
using System.Runtime.InteropServices;
using System.Xml;

namespace PVMgr.Core.Engine
{
    public class MainOrchestrator
    {
        private readonly TestStandService _testStandService;
        private readonly ReportManagerService _reportManagerService;
        private readonly XmlNodeManipulatorService _xmlManipulatorService;
        private readonly FileSystemService _fileSystemService;
        private readonly XmlFileCreatorService _xmlCreatorService;
        private readonly TestStandSyncService _testStandSyncService;
        private readonly TestStandSupervisionService _testStandSupervisionService;

        public MainOrchestrator()
        {
            _testStandService = new TestStandService();
            _reportManagerService = new ReportManagerService();
            _xmlManipulatorService = new XmlNodeManipulatorService();
            _fileSystemService = new FileSystemService();
            _xmlCreatorService = new XmlFileCreatorService();
            _testStandSyncService = new TestStandSyncService();
            _testStandSupervisionService = new TestStandSupervisionService();
        }

        /// <summary>
        /// Point d'entrée principal du moteur de gestion des rapports.
        /// Supervise la file d'attente TestStand, gère le cycle de vie des documents XML et synchronise l'état global.
        /// </summary>
        public void ProcessTestStandCommandsLoop(SequenceContext context, string queueName, string parametersLookupString, string reportsTableLookupString)
        {
            // Initialisation de l'état global
            Exception currentError = null;
            Exception mainLogicError = null;
            List<ReportInfo> reportsList = new List<ReportInfo>();
            var initResult = _testStandService.InitializeTerminationMonitor(context, null);
            StatusMonitor statusMonitor = initResult.MonitorOut;
            Exception monitorError = initResult.ErrorOut;
            bool isStopRequested = false;

            while (!isStopRequested)
            {
                try
                {
                    var paramGetResult = _testStandService.ReadParametersFromSequence(context, parametersLookupString, monitorError);
                    Parameter parameters = paramGetResult.ParamOut;
                    monitorError = paramGetResult.ErrorOut;

                    var timeoutResult = _reportManagerService.ManageReportTimeouts(
                        reportsList,
                        parameters.UseTimeOut,
                        parameters.OpenTimeOut,
                        mainLogicError
                    );
                    reportsList = timeoutResult.ReportsOut;
                    mainLogicError = timeoutResult.ErrorOut;

                    bool isQueueEmpty = true;

                    for (int i = 0; i < 100; i++)
                    {
                        QueueMessageResult msgResult = _testStandService.ReadCommandFromQueue(context, queueName, mainLogicError);
                        object reportContentCom = null; // On prépare la référence COM pour la libérer dans le finally

                        try
                        {
                            if (msgResult.Error != null)
                            {
                                mainLogicError = msgResult.Error;
                            }
                            isQueueEmpty = msgResult.IsEmpty;

                            switch (msgResult.Command)
                            {
                                case "NA":
                                    break;

                                case "post":
                                    var postResult = _testStandService.ParsePostContent(msgResult.CmdContent, mainLogicError);
                                    PostCommandData postData = postResult.DataOut;
                                    mainLogicError = postResult.ErrorOut;

                                    // On capture l'objet COM pour garantir sa libération
                                    reportContentCom = postData.ReportContent;

                                    ReportLookupResult lookupResult = _reportManagerService.LookupReport(reportsList, postData.ReportName, mainLogicError);
                                    mainLogicError = lookupResult.ErrorOut;

                                    ReportOpenResult openResult = _reportManagerService.OpenReportDocument(lookupResult.Report, mainLogicError);
                                    mainLogicError = openResult.ErrorOut;

                                    ReportInfo currentReport = openResult.ReportOut;

                                    if (mainLogicError == null && currentReport.DocRef != null)
                                    {
                                        try
                                        {
                                            XmlDocument xmlDoc = (XmlDocument)currentReport.DocRef;
                                            XmlNode targetNode = xmlDoc.SelectSingleNode(postData.XPath);

                                            if (targetNode == null)
                                            {
                                                mainLogicError = new Exception($"XPATH introuvable : {postData.XPath}");
                                                mainLogicError.Data["Code"] = -1;
                                            }
                                            else
                                            {
                                                mainLogicError = _xmlManipulatorService.ManipulateXmlNode(
                                                    xmlDoc,
                                                    targetNode,
                                                    postData.ReportContent,
                                                    postData.IfExist,
                                                    postData.DataName,
                                                    mainLogicError
                                                );

                                                currentReport.DocRef = xmlDoc;
                                                currentReport.LastUseTime = DateTime.Now;
                                            
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            string errorMessage = $"Plantage lors de l'accès au rapport '{postData.ReportName}'. XPath ciblé : {postData.XPath}";
                                            Logger.WriteError("TS-XML", errorMessage, ex);
                                            mainLogicError = ex;
                                        }
                                    }

                                    if (lookupResult.ReportIndex >= 0 && lookupResult.ReportIndex < reportsList.Count)
                                    {
                                        reportsList[lookupResult.ReportIndex] = currentReport;
                                    }
                                    break;

                                case "new":
                                    var newResult = _testStandService.ParseNewCommandContent(msgResult.CmdContent, mainLogicError);
                                    NewCommandInfo newCmdInfo = newResult.DataOut;
                                    mainLogicError = newResult.ErrorOut;

                                    if (mainLogicError != null) break;

                                    switch (newCmdInfo.IfExist)
                                    {
                                        case "cancel":
                                            Exception cancelError = new Exception($"Opération annulée, le rapport existe déjà : {newCmdInfo.ReportName}");
                                            cancelError.Data["Code"] = -1;
                                            mainLogicError = mainLogicError ?? cancelError;
                                            break;

                                        case "open":
                                            var checkResult = _fileSystemService.CheckIfFileExists(newCmdInfo.FilePath, mainLogicError);
                                            bool isFilePresent = checkResult.Exists;
                                            mainLogicError = checkResult.ErrorOut;

                                            if (!isFilePresent)
                                            {
                                                mainLogicError = _xmlCreatorService.CreateXmlFile(
                                                   newCmdInfo.FilePath,
                                                   newCmdInfo.StyleSheetPath,
                                                   newCmdInfo.MainTag,
                                                   mainLogicError
                                                 );
                                            }

                                            reportsList.Add(new ReportInfo
                                            {
                                                ReportName = newCmdInfo.ReportName,
                                                Path = newCmdInfo.FilePath
                                            });
                                            break;

                                        case "replace":
                                            mainLogicError = _xmlCreatorService.CreateXmlFile(
                                                   newCmdInfo.FilePath,
                                                   newCmdInfo.StyleSheetPath,
                                                   newCmdInfo.MainTag,
                                                   mainLogicError
                                          );

                                            reportsList.Add(new ReportInfo
                                            {
                                                ReportName = newCmdInfo.ReportName,
                                                Path = newCmdInfo.FilePath
                                            });
                                            break;

                                        case "rename":
                                            var uniqueResult = _fileSystemService.GenerateUniqueFilename(newCmdInfo.FilePath, mainLogicError);
                                            string uniquePath = uniqueResult.UniquePath;
                                            mainLogicError = uniqueResult.ErrorOut;

                                            mainLogicError = _xmlCreatorService.CreateXmlFile(
                                                uniquePath,
                                                newCmdInfo.StyleSheetPath,
                                                newCmdInfo.MainTag,
                                                mainLogicError
                                            );

                                            reportsList.Add(new ReportInfo
                                            {
                                                ReportName = newCmdInfo.ReportName,
                                                Path = uniquePath
                                            });
                                            break;
                                    }
                                    break;

                                case "delete":
                                    string reportNameToDelete = msgResult.CmdContent.GetValString("ReportName", 0);

                                    ReportLookupResult lookupResultTodelete = _reportManagerService.LookupReport(reportsList, reportNameToDelete, mainLogicError);

                                    mainLogicError = lookupResultTodelete.ErrorOut;
                                    reportsList = lookupResultTodelete.ReportsOut;
                                    int indexToDelete = lookupResultTodelete.ReportIndex;
                                    ReportInfo reportToSaveAndClose = lookupResultTodelete.Report;

                                    if (indexToDelete >= 0)
                                    {
                                        reportsList.RemoveAt(indexToDelete);
                                        List<ReportInfo> singleReportList = new List<ReportInfo> { reportToSaveAndClose };
                                        _reportManagerService.ManageReportTimeouts(singleReportList, 0, 0, mainLogicError);
                                    }
                                    break;
                            }
                        }
                        finally
                        {
                            // 🧹 NETTOYAGE GARANTI : S'exécute toujours, même si un "case" plante en plein milieu
                            if (msgResult != null && msgResult.CmdContent != null && Marshal.IsComObject(msgResult.CmdContent))
                            {
                                Marshal.ReleaseComObject(msgResult.CmdContent);
                                msgResult.CmdContent = null;
                            }

                            if (reportContentCom != null && Marshal.IsComObject(reportContentCom))
                            {
                                Marshal.ReleaseComObject(reportContentCom);
                                reportContentCom = null;
                            }
                        }
                    }

                    var supervisionResult = _testStandSupervisionService.CheckTerminationStatus(statusMonitor, monitorError);
                    statusMonitor = supervisionResult.MonitorOut;
                    monitorError = supervisionResult.ErrorOut;

                    monitorError = _testStandSyncService.ParamSet_SyncWithTestStand(
                        reportsList,
                        context,
                        reportsTableLookupString,
                        monitorError
                    );

                    bool hasParamSetEror = (monitorError != null);
                    bool hasFatalError = (mainLogicError != null);
                    bool isGracefulStopRequested = (parameters.Stop && isQueueEmpty);
                    bool isAbortRequested = parameters.Abort;
                    bool isManualTermination = supervisionResult.TerminatingOrAborting;

                    isStopRequested = hasFatalError || isGracefulStopRequested || isAbortRequested || isManualTermination || hasParamSetEror;

                    // Libération CPU
                    System.Threading.Thread.Sleep(10);
                }
                catch (Exception ex)
                {
                    Logger.WriteError("ORCHESTRATOR", "Plantage critique inattendu de la boucle principale", ex);
                    currentError = ex;
                    isStopRequested = true;
                }
            }

            try
            {
                // Force la sauvegarde et la fermeture de tous les rapports encore actifs
                var K = _reportManagerService.ManageReportTimeouts(
                    reportsList,
                    0,
                    0,
                    mainLogicError
                );
                mainLogicError = K.ErrorOut;
            }
            catch (Exception ex)
            {
                mainLogicError = mainLogicError ?? ex;
            }

            Exception moniteurError = _testStandSupervisionService.CloseTerminationMonitor(statusMonitor, monitorError);
            Exception finalErrorOut = mainLogicError ?? moniteurError ?? currentError;

            if (finalErrorOut != null)
            {
                string errorCode = finalErrorOut.Data.Contains("Code") ? finalErrorOut.Data["Code"].ToString() : "Inconnu";
                Logger.WriteError("MAIN EXIT", $"Arrêt de l'orchestrateur avec ERREUR (Code: {errorCode})", finalErrorOut);
            }
            else
            {
                Logger.WriteError("MAIN EXIT", "Arrêt complet avec succès. Ressources COM libérées.");
            }
        }
    }
}